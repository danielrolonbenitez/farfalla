<?php
    include('EmailController.php');
    ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
    $from = $_POST['email'];
    $des = array("myayudamutua@gmail.com");
    $subject = "Nuevo mensaje";

    $body="Nombre: ".$_POST['nombre'].'<br/>';
    $body.="Email: ".$_POST['email'].'<br/>';
    $body.="Telefono: ".$_POST['telefono'].'<br/>';
    $body.="Direccion: ".$_POST['direccion'].'<br/>';
    $body.="Mensaje: ".$_POST['mensaje'].'<br/>';

    $mensaje=$body;
    $email= New EmailController();
	 echo $email->enviaEmail($from,$mensaje,$subject,$des);die;
	

?>