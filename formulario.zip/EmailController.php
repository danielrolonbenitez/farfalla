<?php
require_once(dirname(__FILE__)."/PHPMailer/phpmailer.php");
require_once(dirname(__FILE__)."/PHPMailer/class.smtp.php");
//error_reporting(-1);
class EmailController{

    var $mailer;
  
    public function __construct(){  

        $this->mailer = new PHPMailer();
        $this->mailer->SMTPDebug = SMTP::DEBUG_SERVER; 
        $this->mailer->IsSMTP(); // telling the class to use SMTP
        $this->mailer->IsHTML(true); // Envio tipo HTML
        $this->mailer->SMTPAuth = true;
        $this->mailer->SMTPSecure = 'ssl';
        $this->mailer->Port = 465;
        $this->mailer->Priority = 1; // ******** PRIORIDAD *******
        $this->mailer->Host ="smtp.gmail.com"; //Modificar por el host de salida
        $this->mailer->Username ="myayudamutua@gmail.com";    // SMTP username -- CHANGE --
        $this->mailer->Password ="nrfh ypmc mncx yaqo";    // SMTP password -- CHANGE --
        $this->mailer->CharSet = 'utf-8'; 
        $this->mailer->WordWrap =50;
      }

    public function enviaEmail($from,$mensaje,$asunto,$des,$files=null){

       
         $from=$from;
         $fromEmail=$from;
        
        $this->mailer->Subject = $asunto;
        $this->mailer->ClearAllRecipients();
        $this->mailer->setFrom($fromEmail, $from); 

        if(count($des)>0){   
              foreach($des as $destinatario){
                $this->mailer->AddAddress($destinatario);
              }
            }else{
                $this->mailer->AddAddress($fromEmail);
                $mensaje="error en la direccion de email al enviar el email.";
              }
             $this->mailer->Body = $mensaje;
              if($files){
               // var_dump($files);die;
              $file_tmp  = $files['image']['tmp_name'];
              $file_name = $files['image']['name'];
              $this->mailer->AddAttachment($file_tmp, $file_name);
              }


            $send=$this->mailer->send();
          if($send==false){
            return "Failed: ".$this->mailer->ErrorInfo;
        }else{
              return 1;
               }
        

            
    }
    
}

?>
